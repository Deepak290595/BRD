package com.nucleus.validation;
import com.nucleus.domain.Customer;
import java.util.regex.*;

public class Validation {

	public boolean validate(Customer customer){
		Validation validation= new Validation();
		if(validation.validateCode(customer)==true&&
				validation.validateName(customer)==true&&
				validation.validateAddress1(customer)==true&&
				validation.validatePincode(customer)==true&&
				validation.validateEmail(customer)==true&&
				validation.validatePrimary(customer)==true&&
				validation.validateRecord(customer)==true&&
				validation.validateFlag(customer)==true&&
				validation.validateDate(customer)==true&&
				validation.validateCreator(customer)==true)
			return true;
		else
			return false;
	}
	public boolean validateCode(Customer customer){
		if(customer.getcCode().length()!=0)
			return true;
		else
			return false;
		}
	public boolean validateName(Customer customer){
	if(Pattern.matches("^[A-Za-z0-9]$",customer.getcName())||customer.getcName().length()!=0)
		return true;
	else
		return false;
	}
	public boolean validateAddress1(Customer customer){
		if(customer.getcAddress1().length()!=0)
			return true;
		else
			return false;
		}
	public boolean validatePincode(Customer customer){
		if(Pattern.matches("^[0-9]{6}$", customer.getcPinCode())&&customer.getcPinCode().length()!=0)
			return true;
		else
			return false;
	}
	public boolean validateEmail(Customer customer){
		if(Pattern.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$", customer.getcEmail())&&customer.getcEmail().length()!=0)
			return true;
		else
			return false;
	}
	public boolean validatePrimary(Customer customer){
		if(customer.getcPrimaryContactPerson().length()!=0)
			return true;
		else
			return false;
		}
	public boolean validateRecord(Customer customer){
		if(Pattern.matches("^[A]|[N]|[D]|[R]|[M]$", customer.getcRecordStatus())&&customer.getcRecordStatus().length()!=0)
			return true;
		else
			return false;
	}
	public boolean validateFlag(Customer customer){
		if(Pattern.matches("^[A]|[I]$",customer.getcActiveInactiveFlag())&&customer.getcActiveInactiveFlag().length()!=0)
			return true;
		else
			return false;
	}
	public boolean validateDate(Customer customer){
		if(customer.getcCreateDate().length()!=0)
			return true;
		else
			return false;
		}
	public boolean validateCreator(Customer customer){
		if(customer.getcCreatedBy().length()!=0)
			return true;
		else
			return false;
		}
}
