package com.nucleus.main;
import com.nucleus.dao.* ;

public class CustomerMain {
	
	public static void main(String[] args) {
		CustomerDAOImp customerDAOImp = new CustomerDAOImp();
		customerDAOImp.fileRead();
	}
}
