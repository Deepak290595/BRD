package com.nucleus.domain;

public class Customer {
	private String cID;
	private String cCode;
	private String cName;
	private String cAddress1;
	private String cAddress2;
	private String cPinCode;
	private String cEmail;
	private String cNumber;
	private String cPrimaryContactPerson;
	private String cRecordStatus;
	private String cActiveInactiveFlag;
	private String cCreateDate;
	private String cCreatedBy;
	private String cModifiedDate;
	private String cModifiedBy;
	private String cAuthorizedDate;
	private String cAuthorizedBy;
	public String getcID() {
		return cID;
	}
	public void setcID(String cID) {
		this.cID = cID;
	}
	public String getcCode() {
		return cCode;
	}
	public void setcCode(String cCode) {
		this.cCode = cCode;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcAddress1() {
		return cAddress1;
	}
	public void setcAddress1(String cAddress1) {
		this.cAddress1 = cAddress1;
	}
	public String getcAddress2() {
		return cAddress2;
	}
	public void setcAddress2(String cAddress2) {
		this.cAddress2 = cAddress2;
	}
	public String getcPinCode() {
		return cPinCode;
	}
	public void setcPinCode(String cPinCode) {
		this.cPinCode = cPinCode;
	}
	public String getcEmail() {
		return cEmail;
	}
	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}
	public String getcNumber() {
		return cNumber;
	}
	public void setcNumber(String cNumber) {
		this.cNumber = cNumber;
	}
	public String getcPrimaryContactPerson() {
		return cPrimaryContactPerson;
	}
	public void setcPrimaryContactPerson(String cPrimaryContactPerson) {
		this.cPrimaryContactPerson = cPrimaryContactPerson;
	}
	public String getcRecordStatus() {
		return cRecordStatus;
	}
	public void setcRecordStatus(String cRecordStatus) {
		this.cRecordStatus = cRecordStatus;
	}
	public String getcActiveInactiveFlag() {
		return cActiveInactiveFlag;
	}
	public void setcActiveInactiveFlag(String cActiveInactiveFlag) {
		this.cActiveInactiveFlag = cActiveInactiveFlag;
	}
	public String getcCreateDate() {
		return cCreateDate;
	}
	public void setcCreateDate(String cCreateDate) {
		this.cCreateDate = cCreateDate;
	}
	public String getcCreatedBy() {
		return cCreatedBy;
	}
	public void setcCreatedBy(String cCreatedBy) {
		this.cCreatedBy = cCreatedBy;
	}
	public String getcModifiedDate() {
		return cModifiedDate;
	}
	public void setcModifiedDate(String cModifiedDate) {
		this.cModifiedDate = cModifiedDate;
	}
	public String getcModifiedBy() {
		return cModifiedBy;
	}
	public void setcModifiedBy(String cModifiedBy) {
		this.cModifiedBy = cModifiedBy;
	}
	public String getcAuthorizedDate() {
		return cAuthorizedDate;
	}
	public void setcAuthorizedDate(String cAuthorizedDate) {
		this.cAuthorizedDate = cAuthorizedDate;
	}
	public String getcAuthorizedBy() {
		return cAuthorizedBy;
	}
	public void setcAuthorizedBy(String cAuthorizedBy) {
		this.cAuthorizedBy = cAuthorizedBy;
	}
	public Customer(String cID, String cCode, String cName, String cAddress1,
			String cAddress2, String cPinCode, String cEmail, String cNumber,
			String cPrimaryContactPerson, String cRecordStatus,
			String cActiveInactiveFlag, String cCreateDate, String cCreatedBy,
			String cModifiedDate, String cModifiedBy, String cAuthorizedDate,
			String cAuthorizedBy) {
		this.cID = cID;
		this.cCode = cCode;
		this.cName = cName;
		this.cAddress1 = cAddress1;
		this.cAddress2 = cAddress2;
		this.cPinCode = cPinCode;
		this.cEmail = cEmail;
		this.cNumber = cNumber;
		this.cPrimaryContactPerson = cPrimaryContactPerson;
		this.cRecordStatus = cRecordStatus;
		this.cActiveInactiveFlag = cActiveInactiveFlag;
		this.cCreateDate = cCreateDate;
		this.cCreatedBy = cCreatedBy;
		this.cModifiedDate = cModifiedDate;
		this.cModifiedBy = cModifiedBy;
		this.cAuthorizedDate = cAuthorizedDate;
		this.cAuthorizedBy = cAuthorizedBy;
	}
	@Override
	public String toString() {
		return "Customer [cID=" + cID + ", cCode=" + cCode + ", cName=" + cName
				+ ", cAddress1=" + cAddress1 + ", cAddress2=" + cAddress2
				+ ", cPinCode=" + cPinCode + ", cEmail=" + cEmail
				+ ", cNumber=" + cNumber + ", cPrimaryContactPerson="
				+ cPrimaryContactPerson + ", cRecordStatus=" + cRecordStatus
				+ ", cActiveInactiveFlag=" + cActiveInactiveFlag
				+ ", cCreateDate=" + cCreateDate + ", cCreatedBy=" + cCreatedBy
				+ ", cModifiedDate=" + cModifiedDate + ", cModifiedBy="
				+ cModifiedBy + ", cAuthorizedDate=" + cAuthorizedDate
				+ ", cAuthorizedBy=" + cAuthorizedBy + "]";
	}
	
	
}
