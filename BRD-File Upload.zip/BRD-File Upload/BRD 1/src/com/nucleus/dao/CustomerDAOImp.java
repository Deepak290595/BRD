package com.nucleus.dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.nucleus.connection1.*;
import com.nucleus.validation.Validation;
import com.nucleus.domain.Customer;
import com.nucleus.error.*;

public class CustomerDAOImp implements CustomerDAO{
	
	FileReader fileReader;
	Customer customer;
	Validation validation=new Validation();
	
	PreparedStatement preparedStatement;
	@Override
	public Customer fileRead() {
		CustomerDAOImp customerDAOImp =  new CustomerDAOImp();
		try {
			fileReader = new FileReader("C:/Users/temp/Desktop/BRD-File Upload/Test Cases/testCase1.txt");
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String string = bufferedReader.readLine();
			while(string!=null){
				String [] arrOfStr = string.split("~",-1);
				String id = "1";
				String code = arrOfStr[0];
				String name = arrOfStr[1];
				String address1 = arrOfStr[2];
				String address2 = arrOfStr[3];
				String pin =arrOfStr[4];
				String email = arrOfStr[5];
				String num = arrOfStr[6];
				String person = arrOfStr[7];
				String status = arrOfStr[8];
				String flag = arrOfStr[9];
				String cDate = arrOfStr[10];
				String createdBy = arrOfStr[11];
				String mDate = arrOfStr[12];
				String modifiedBy = arrOfStr[13];
				String aDate = arrOfStr[14];
				String authorisedBy = arrOfStr[15];
				Customer customer = new Customer(id,code,name,address1,address2,pin,email,num,person,status,flag,cDate,createdBy,mDate,modifiedBy,
						aDate,authorisedBy);
				if(validation.validate(customer)==true){
					customerDAOImp.tableWrite(customer);
				}
				else{
					ErrorLog errorLog = new ErrorLog(customer);
				}
					
				string = bufferedReader.readLine();
		} 
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}		
		return customer;
	}

	@Override
	public void tableWrite(Customer customer) {
		ConnectionSetup connectionSetup= new ConnectionSetup();
		Connection connection = connectionSetup.createConnection();
		try {
			preparedStatement = connection.prepareStatement("insert into customermasterbydeepak values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1,customer.getcID());
			preparedStatement.setString(2,customer.getcCode());
			preparedStatement.setString(3,customer.getcName());
			preparedStatement.setString(4,customer.getcAddress1());
			preparedStatement.setString(5,customer.getcAddress2());
			preparedStatement.setString(6,customer.getcPinCode());
			preparedStatement.setString(7,customer.getcEmail());
			preparedStatement.setString(8,customer.getcNumber());
			preparedStatement.setString(9,customer.getcPrimaryContactPerson());
			preparedStatement.setString(10,customer.getcRecordStatus());
			preparedStatement.setString(11,customer.getcActiveInactiveFlag());
			preparedStatement.setString(12,customer.getcCreateDate());
			preparedStatement.setString(13,customer.getcCreatedBy());
			preparedStatement.setString(14,customer.getcModifiedDate());
			preparedStatement.setString(15,customer.getcModifiedBy());
			preparedStatement.setString(16,customer.getcAuthorizedDate());
			preparedStatement.setString(17,customer.getcAuthorizedBy());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				connection.close();
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
