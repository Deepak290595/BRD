package com.nucleus.dao;

import com.nucleus.domain.Customer;

public interface CustomerDAO {
	public Customer fileRead();
	public void tableWrite(Customer customer);
}
