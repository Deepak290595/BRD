package com.nucleus.error;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import com.nucleus.domain.Customer;

public class ErrorLog {
	FileWriter fileWriter;
	public ErrorLog(Customer customer) {
		try {
			fileWriter = new FileWriter("C:/Users/temp/Desktop/Test/errorlog.txt",true);
			PrintWriter printWriter = new PrintWriter(fileWriter);
			printWriter.format("%s\n", customer);
			printWriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally{
			try {
				fileWriter.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
